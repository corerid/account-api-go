package main
// Basic response struct
type BasicResponse struct {
    Error       int `json:"error"`
    Message     string `json:"message"`
}

type repositorySummary struct {
	ID         int
	Name       string
	Owner      string
	TotalStars int
}

type repositories struct {
	Repositories []repositorySummary
}

