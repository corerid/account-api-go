package main
import (
    "github.com/gorilla/mux"
    "net/http"
)
// Struct for a Route
type Route struct {
    Name        string
    Method      string
    Pattern     string
    HandlerFunc http.HandlerFunc
}
// Array of Route
type Routes []Route
// initiate the router
func NewRouter() *mux.Router {
    router := mux.NewRouter().StrictSlash(true)
    // declare routes
    var routes = Routes{
        Route{
            "getIndex",
            "GET",
            "/getQ/{id}/{name}",
            getIndex,
        },
        Route{
            "getJson",
            "GET",
            "/getJson",
            getJson,
        },
        Route{
            "insert",
            "POST",
            "/insert",
            insert,
        },
        Route{
            "delete",
            "DELETE",
            "/delete/{id}",
            delete,
        },
    }
    // bind routes
    for _, route := range routes {
        router.
            Methods(route.Method).
            Path(route.Pattern).
            Name(route.Name).
            Handler(route.HandlerFunc)
    }
    return router
}